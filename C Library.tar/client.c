#include "defs.h"


int main()
{
  int  choice = -1;
  
  int socket;
  setupClientSocket(&socket);
  char receiveBuffer[MAX_BUFF];
  char requestBuffer[MAX_BUFF];
  char str[MAX_STR];
  int status;

  while (1) {

   clientMenu(&choice);

   switch(choice) {

      case 1:   // Print books
        sprintf(requestBuffer,"%d", 0);
        sendData(socket,requestBuffer);
        rcvData(socket,receiveBuffer);
        printf("%s",receiveBuffer);
        break;

      case 2:   // Check out a book
        printf("Enter book id: ");
        fgets(str, sizeof(str), stdin);
        sprintf(requestBuffer, "%d %s", 2, str);
        sendData(socket,requestBuffer);
        
        rcvData(socket,receiveBuffer);
        sscanf(receiveBuffer, "%d", &status);
        if (status == 0){
           printf("Book id was successfully checked out");
        }
        if (status == -2){
           printf("Book id was not found");
        }
        if (status == -3){
           printf("Book id is not available");
        }
        
        
        break;

      case 3:   // Check in a book
         printf("Enter book id: ");
        fgets(str, sizeof(str), stdin);
        sprintf(requestBuffer, "%d %s", 1, str);
        sendData(socket,requestBuffer);
        
        rcvData(socket,receiveBuffer);
        sscanf(receiveBuffer, "%d", &status);
        if (status == 0){
           printf("Book id was successfully checked in");
        }
        if (status == -2){
           printf("Book id was not found");
        }
        if (status == -3){
           printf("Book id is not available");
        }

        break;

      case 0:   // Close everything
        sprintf(requestBuffer,"%d", 3);
        sendData(socket,requestBuffer);
        close(socket);
        return 0;
        break;

      default:
        printf("ERROR:  invalid option\n");
    }
    
  }

  return 0;
}

void clientMenu(int* choice)
{
  int c = -1;
  int numOptions = 3;
  char str[MAX_STR];

  printf("\nMAIN MENU\n");
  printf("  (1) Print books\n");
  printf("  (2) Check out a book\n");
  printf("  (3) Check in a book\n");
  printf("  (0) Exit\n\n");

  printf("Please enter your selection: ");
  fgets(str, sizeof(str), stdin);
  str[strcspn(str, "\n")] = 0;
  sscanf(str, "%d", &c);

  if (c == 0) {
    *choice = c;
    return;
  }

  while (c < 0 || c > numOptions) {
    printf("Please enter your selection: ");
    fgets(str, sizeof(str), stdin);
    sscanf(str, "%d", &c);
  }

  *choice = c;
}

