#include "defs.h"

int listenSocket;

int main()
{
  LibraryType *library;
  int socket;
  initLibrary(&library, "name");
  setupServerSocket(&listenSocket);
  signal(SIGUSR1, handleSig1);
  printf("Waiting for connection request...\n");
  acceptConnection(listenSocket, &socket);
  printf("... conected\n");
  serveOneClient(socket, library);
  return 0;
}

/*
  Function:  serveOneClient
  Purpose:   serves all the requests from the client process.
       in:   int clientSocket, LibraryType *lib.
      out:   requested client information.
   return:   nothing.
*/
void serveOneClient(int clientSocket, LibraryType *lib){
   char buffer[MAX_BUFF];
   int request;
   char libraryStr[MAX_BUFF];
   int status;
   int id;
   char resultStr[MAX_STR];
   
   while(1){
      printf("Waiting for message...\n");
      rcvData(clientSocket, buffer);
      printf("... received\n");
      
      request = buffer[0] -'0';
      
      if(request == REQ_RET_BOOKS){
         formatBooks(&lib->books,libraryStr);
         sendData(clientSocket, libraryStr); 
      }
      
      if(request == REQ_CHECK_OUT){
         sscanf(buffer, "%d %d", &request, &id);
         status = checkOutBook(lib, id);
         sprintf(resultStr,"%d",status);
         sendData(clientSocket, resultStr);
      }
      
      if(request == REQ_CHECK_IN){
         sscanf(buffer, "%d %d", &request, &id);
         status = checkInBook(lib, id);
         sprintf(resultStr,"%d",status);
         sendData(clientSocket, resultStr);
      }
      
      if(request == REQ_CLOSE){
         printf("Shutting down...\n");
         printf("... done\n");
         closeAll(lib);
         break;
      }
   }
}

/*
  Function:  closeAll
  Purpose:   cleans up all the server resources.
       in:   LibraryType *lib.
      out:   freed resources.
   return:   nothing.
*/
void closeAll(LibraryType *lib){
  close(listenSocket);
  cleanupLibrary(lib);
}

/*
  Function:  handleSig1
  Purpose:   cleans up the server resources as much as possible.
       in:   int.
      out:   freed resources.
   return:   nothing.
*/
void handleSig1(int i){
  printf("Shutting down...\n");
  printf("... done\n");
  close(listenSocket);
  exit(SIGUSR1);
}

